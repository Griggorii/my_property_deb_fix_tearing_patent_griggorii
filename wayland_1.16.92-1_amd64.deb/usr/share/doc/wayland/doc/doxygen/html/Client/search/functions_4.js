var searchData=
[
  ['message_5fcount_5ffds',['message_count_fds',['../wayland-client_8c.html#a6a1fe07ff2b7d59ddff17483c4f1c6f0',1,'wayland-client.c']]]
];
