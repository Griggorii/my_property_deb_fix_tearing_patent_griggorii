var searchData=
[
  ['free_5fzombies',['free_zombies',['../wayland-client_8c.html#a9679d3a2ad982bd69b38d56e7e491102',1,'wayland-client.c']]]
];
