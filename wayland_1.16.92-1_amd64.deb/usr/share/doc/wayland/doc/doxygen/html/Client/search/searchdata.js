var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvw",
  1: "w",
  2: "mw",
  3: "cdfimpqrsvw",
  4: "abcdefghiklmnoprstuvw",
  5: "w",
  6: "w",
  7: "w",
  8: "w",
  9: "_w",
  10: "t",
  11: "tw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

