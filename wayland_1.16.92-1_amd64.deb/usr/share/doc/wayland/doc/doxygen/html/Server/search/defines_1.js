var searchData=
[
  ['lock_5fsuffix',['LOCK_SUFFIX',['../wayland-server_8c.html#a11aa03fdbf1a2680335dcaa0c73f25e3',1,'wayland-server.c']]],
  ['lock_5fsuffixlen',['LOCK_SUFFIXLEN',['../wayland-server_8c.html#a55f0760f271ff025b986de41b1e9f11e',1,'wayland-server.c']]]
];
