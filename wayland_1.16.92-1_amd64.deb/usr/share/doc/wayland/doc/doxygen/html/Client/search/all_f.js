var searchData=
[
  ['ping',['ping',['../structwl__shell__surface__listener.html#af67de0887e95b9f436a501d348b851fc',1,'wl_shell_surface_listener']]],
  ['popup_5fdone',['popup_done',['../structwl__shell__surface__listener.html#af98578a59fe1f5f853197890a13bfe41',1,'wl_shell_surface_listener']]],
  ['prepare_5fzombie',['prepare_zombie',['../wayland-client_8c.html#a1759edc352d6378a73c6cc0199216814',1,'wayland-client.c']]],
  ['prev',['prev',['../structwl__list.html#a72c2827d3103691f9e3299babfbf0704',1,'wl_list']]],
  ['proxy_5fcreate',['proxy_create',['../wayland-client_8c.html#a975a51f5b5bf3adfc83f318da0237d43',1,'wayland-client.c']]],
  ['proxy_5fdestroy',['proxy_destroy',['../wayland-client_8c.html#a832fd28eed8006b3268302ba4f663d87',1,'wayland-client.c']]]
];
