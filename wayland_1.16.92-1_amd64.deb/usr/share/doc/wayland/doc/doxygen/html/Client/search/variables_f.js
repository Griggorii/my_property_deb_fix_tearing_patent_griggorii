var searchData=
[
  ['release',['release',['../structwl__buffer__listener.html#a437b4c846e2a303b7632dff16aaffb3e',1,'wl_buffer_listener']]],
  ['repeat_5finfo',['repeat_info',['../structwl__keyboard__listener.html#a2f11685e143ddce454e10bac0559a744',1,'wl_keyboard_listener']]]
];
