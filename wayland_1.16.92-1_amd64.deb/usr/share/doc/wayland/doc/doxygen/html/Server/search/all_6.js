var searchData=
[
  ['f',['f',['../unionwl__argument.html#a85b9cba149294b6d0a3a5c6a6d73425b',1,'wl_argument']]],
  ['fallback_5fmapping_5fused',['fallback_mapping_used',['../structwl__shm__sigbus__data.html#a963de4dc248750a802d7a97258ce2a25',1,'wl_shm_sigbus_data']]],
  ['fd',['fd',['../structwl__socket.html#a84107d8f8948c572733d9dbcce799cd6',1,'wl_socket']]],
  ['fd_5flock',['fd_lock',['../structwl__socket.html#addbfff96411375cc5db3a446a42a3dd5',1,'wl_socket']]],
  ['fd_5fsource_5finterface',['fd_source_interface',['../event-loop_8c.html#adc0a5c96e8b62776564c8479ae547943',1,'event-loop.c']]],
  ['finish',['finish',['../structwl__data__offer__interface.html#a78a9a38cb4ced91535b4b139e45aa54d',1,'wl_data_offer_interface']]],
  ['format',['format',['../structwl__shm__buffer.html#ab62701b55dde79ce9beb612d40712570',1,'wl_shm_buffer']]],
  ['format_5fis_5fsupported',['format_is_supported',['../wayland-shm_8c.html#a57bb7efd1bf178739decdb48591b9f79',1,'wayland-shm.c']]],
  ['frame',['frame',['../structwl__surface__interface.html#a7d43f0020ba1bf2b3006070de43103f2',1,'wl_surface_interface']]],
  ['func',['func',['../structwl__protocol__logger.html#aec3f6877750bee41e198ee0ba86ec74a',1,'wl_protocol_logger']]]
];
