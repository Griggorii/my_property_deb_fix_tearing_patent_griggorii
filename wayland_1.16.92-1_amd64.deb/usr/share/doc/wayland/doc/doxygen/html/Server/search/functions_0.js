var searchData=
[
  ['_5fwl_5fdisplay_5fadd_5fsocket',['_wl_display_add_socket',['../wayland-server_8c.html#a83bb0db9e4a3c64b5d551774c007f9d1',1,'wayland-server.c']]]
];
