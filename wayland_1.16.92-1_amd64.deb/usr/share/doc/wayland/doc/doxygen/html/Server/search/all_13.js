var searchData=
[
  ['verify_5fobjects',['verify_objects',['../wayland-server_8c.html#a5e6257b74e73e94c150cec6bd966c519',1,'wayland-server.c']]],
  ['version',['version',['../structwl__interface.html#ac7b9bc6c0352b4100213109094ca55fa',1,'wl_interface::version()'],['../structwl__global.html#a9fbdb3d5a4f47de7b3c8184af910244b',1,'wl_global::version()'],['../structwl__resource.html#a30ccbcc8013ea4122815da0789a36210',1,'wl_resource::version()']]]
];
