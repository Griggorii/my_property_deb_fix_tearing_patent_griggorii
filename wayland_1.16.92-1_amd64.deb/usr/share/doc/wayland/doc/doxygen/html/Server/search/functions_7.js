var searchData=
[
  ['log_5fclosure',['log_closure',['../wayland-server_8c.html#a1cd4d754208ed7c774beb192cdb33e15',1,'wayland-server.c']]]
];
