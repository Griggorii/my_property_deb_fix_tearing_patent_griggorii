var searchData=
[
  ['_5fgnu_5fsource',['_GNU_SOURCE',['../wayland-server_8c.html#a369266c24eacffb87046522897a570d5',1,'_GNU_SOURCE():&#160;wayland-server.c'],['../wayland-shm_8c.html#a369266c24eacffb87046522897a570d5',1,'_GNU_SOURCE():&#160;wayland-shm.c']]],
  ['_5fwl_5fdisplay_5fadd_5fsocket',['_wl_display_add_socket',['../wayland-server_8c.html#a83bb0db9e4a3c64b5d551774c007f9d1',1,'wayland-server.c']]]
];
