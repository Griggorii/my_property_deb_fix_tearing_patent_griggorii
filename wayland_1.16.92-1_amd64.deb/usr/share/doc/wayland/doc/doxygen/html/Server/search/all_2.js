var searchData=
[
  ['bind',['bind',['../structwl__global.html#acc985dddfc0a75b454187c062c054e67',1,'wl_global::bind()'],['../structwl__registry__interface.html#a493b9ce66635254c682ed0e06ed01827',1,'wl_registry_interface::bind()']]],
  ['bind_5fdisplay',['bind_display',['../wayland-server_8c.html#a9ca6bf2b19fc16d56ec13d584adc32d0',1,'wayland-server.c']]],
  ['bind_5fshm',['bind_shm',['../wayland-shm_8c.html#a233891736e7af8c89af406d21aeeb930',1,'wayland-shm.c']]]
];
