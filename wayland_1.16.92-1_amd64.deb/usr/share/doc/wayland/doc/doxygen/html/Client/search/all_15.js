var searchData=
[
  ['validate_5fclosure_5fobjects',['validate_closure_objects',['../wayland-client_8c.html#aec644263e1f8bf2fab9ccfffbe3d9a3b',1,'wayland-client.c']]],
  ['version',['version',['../structwl__interface.html#ac7b9bc6c0352b4100213109094ca55fa',1,'wl_interface']]]
];
